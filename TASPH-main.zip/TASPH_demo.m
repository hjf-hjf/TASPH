function TASPH_demo()
addpath(genpath(fullfile('utils/')));
% rng('default');

dataname = 'mirflickr25k';
txtname = 'log';
name = strcat(txtname,'.txt');
%% parameters setting
param.dataname = dataname;
param.method = 'TASPH'; 

% experinment parameters
bits1 = [16];
bits2 = [16];
param.maxIter = 25;

% tradeoff   parameters
gamma = [1e0]; 
lambda = [8];  
rou = [1e6]; 
eta = [1e-2];      
alpha = [1e-3];    

%% load dataset
dataset = load_data(dataname);
n_anchors = 1500;
rbf2;

%% run algorithm
fid = fopen(name,'a+');
fprintf(fid,'%5s\r\n',' ');
fprintf(fid,'%5s\t','    anchors =');
fprintf(fid,'%8g\r\n',n_anchors);
for o = 1:length(bits1)
    for p = 1:length(bits2)
        for h = 1:length(gamma)
             for i = 1:length(lambda) 
                  for j = 1:length(rou) 
                      for l = 1:length(eta)
                          for q = 1:length(alpha)
                                param.gamma = gamma(h);
                                param.lambda = lambda(i);
                                param.rou = rou(j);
                                param.eta = eta(l);
                                param.alpha = alpha(q);
                                param.bits1 = bits1(o);
                                param.bits2 = bits2(p);  
%                                 rng('default');

                                fprintf(fid,'...bit: %d to %d\n', param.bits1,param.bits2); 
                                param.num_samples1 = 2 * param.bits1;
                                param.num_samples2 = 2 * param.bits2;
                                trainL = dataset.databaseL;
                                [IT,TI] = TASPH(trainL, param, dataset);

                                fprintf(fid,'%5s','gamma =');
                                fprintf(fid,'%8.5g\t',param.gamma);
                                fprintf(fid,'%5s','lambda =');
                                fprintf(fid,'%8.5g\t',param.lambda);
                                fprintf(fid,'%5s','rou =');
                                fprintf(fid,'%8.5g\t',param.rou);
                                fprintf(fid,'%5s','eta =');
                                fprintf(fid,'%8.5g\t',param.eta);
                                fprintf(fid,'%5s','alpha =');
                                fprintf(fid,'%8.5g\t',param.alpha);
                                fprintf(fid,'\t');

                                fprintf(fid,'Image_to_Text_MAP: %f ; Text_to_Image_MAP: %f ; \n\n',IT.map,TI.map);
                          end
                      end
                  end
             end
        end
    end 
end    
end

