function dataset = load_data(dataname)
switch dataname
    case 'nus-vgg'
        load ./data/mynus_cnn.mat I_te I_tr T_te T_tr L_te L_tr;
        dataset.XTest = I_te;
        dataset.YTest = T_te;
        dataset.XDatabase = I_tr;
        dataset.YDatabase = T_tr;
        dataset.testL = L_te;
        dataset.databaseL = L_tr;
        case 'wiki_data'
        load ./data/wiki_data.mat I_te I_tr T_te T_tr L_te L_tr;
        inx = randperm(size(L_tr,1),size(L_tr,1));
        dataset.XTest = I_te;
        dataset.YTest = T_te;
        dataset.XDatabase = I_tr(inx,:);
        dataset.YDatabase = T_tr(inx,:);
        dataset.testL = L_te;
        dataset.databaseL = L_tr(inx,:);
    case 'flickr-25k'
        load ./data/flickr-25k.mat XTest YTest XDatabase YDatabase testL databaseL;
        inx = randperm(size(databaseL,1),size(databaseL,1));
        dataset.XTest = XTest;
        dataset.YTest = YTest;
        dataset.XDatabase = XDatabase(inx,:);
        dataset.YDatabase = YDatabase(inx,:);
        dataset.testL = testL;
        dataset.databaseL = databaseL(inx,:);
    case 'mirflickr25k'
        load ./data/mirflickr25k.mat I_te T_te I_tr T_tr L_te L_tr;
        inx = randperm(size(L_tr,1),size(L_tr,1));
        dataset.XTest = I_te;
        dataset.YTest = T_te;
        dataset.XDatabase = I_tr(inx,:);
        dataset.YDatabase = T_tr(inx,:);
        dataset.testL = L_te;
        dataset.databaseL = L_tr(inx,:);
    case 'mirflickr'
        load ./data/mirflickr25k.mat I_te T_te I_tr T_tr L_te L_tr;
        inx = randperm(size(L_tr,1),size(L_tr,1));
        dataset.XTest = I_te;
        dataset.YTest = T_te;
        dataset.XDatabase = I_tr(inx,:);
        dataset.YDatabase = T_tr(inx,:);
        dataset.testL = L_te;
        dataset.databaseL = L_tr(inx,:);
    case 'flickr-25k-vgg'
        load ./data/flickr-25k.mat VTest YTest VDatabase YDatabase testL databaseL;
        inx = randperm(size(databaseL,1),10000);
        dataset.XTest = VTest;
        dataset.YTest = YTest;
        dataset.XDatabase = VDatabase(inx,:);
        dataset.YDatabase = YDatabase(inx,:);
        dataset.testL = testL;
        dataset.databaseL = databaseL(inx,:);
    case 'IAPRTC-12'
        load ./data/IAPRTC-12.mat I_te T_te I_tr T_tr L_te L_tr;
        inx = randperm(size(L_tr,1),size(L_tr,1));
        dataset.XTest = I_te;
        dataset.YTest = T_te;
        dataset.XDatabase = I_tr(inx,:);
        dataset.YDatabase = T_tr(inx,:);
        dataset.testL = L_te;
        dataset.databaseL = L_tr(inx,:);
    case 'iapr-tc12-vgg'
        load ./data/iapr-tc12.mat VTest YTest VDatabase YDatabase testL databaseL;
        inx = randperm(size(databaseL,1),10000);
        dataset.XTest = VTest;
        dataset.YTest = YTest;
        dataset.XDatabase = VDatabase;
        dataset.YDatabase = YDatabase;
        dataset.testL = testL;
        dataset.databaseL = databaseL;
    case 'nus-wide-tc10'
        load ./data/nus-wide-clear.mat XTest YTest XDatabase YDatabase testL databaseL;
        inx = randperm(size(databaseL,1),3000);
        dataset.XTest = XTest;
        dataset.YTest = YTest;
        dataset.XDatabase = XDatabase(inx,:);
        dataset.YDatabase = YDatabase(inx,:);
        dataset.testL = testL;
        dataset.databaseL = databaseL(inx,:);
    case 'nus-wide-tc10-vgg'
        load ./data/nus-wide.mat VTest YTest VDatabase YDatabase testL databaseL;
        inx = randperm(size(databaseL,1),15000);
        dataset.XTest = VTest;
        dataset.YTest = YTest;
        dataset.XDatabase = VDatabase(inx,:);
        dataset.YDatabase = YDatabase(inx,:);
        dataset.testL = testL;
        dataset.databaseL = databaseL(inx,:);
         case 'nusData'
        load ./data/nusData.mat I_te T_te I_tr T_tr L_te L_tr;
        inx = randperm(size(L_tr,1),20000);
        dataset.XTest = I_te;
        dataset.YTest = T_te;
        dataset.XDatabase = I_tr(inx,:);
        dataset.YDatabase = T_tr(inx,:);
        dataset.testL = L_te;
        dataset.databaseL = L_tr(inx,:);
    case 'NUS21_deep'
        load ./data/NUS21_deep.mat L X Y;
        R = randperm(size(L,1));
        sampleInds = R(2001:end);
        queryInds = R(1:2000);
        dataset.XTest = X(queryInds,:);
        dataset.YTest = Y(queryInds,:);
        dataset.XDatabase = X(sampleInds,:);
        dataset.YDatabase = Y(sampleInds,:);
        dataset.testL = L(queryInds,:);
        dataset.databaseL = L(sampleInds,:);
   
end
end

