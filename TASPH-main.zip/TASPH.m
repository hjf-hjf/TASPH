function [ImgToTxt, TxtToImg] = TASPH(trainLabel, param, dataset)

X1 = dataset.XDatabase;
X2 = dataset.YDatabase;
XTest = dataset.XTest;
YTest = dataset.YTest;
testL = dataset.testL;
databaseL = dataset.databaseL;
topk = 1000;

[~,d1] = size(X1);
[d,d2] = size(X2);
bit1 = param.bits1;
bit2 = param.bits2;
maxIter = param.maxIter;
rou = param.rou;
sampleColumn1 = param.num_samples1;
sampleColumn2 = param.num_samples2;
lambda = param.lambda;
gamma = param.gamma;
eta = param.eta;
alpha = param.alpha;

numTrain = size(trainLabel, 1);

B1 = ones(numTrain, bit1);
B1(randn(numTrain, bit1) < 0) = -1;
B1(B1 > 0) = 1;
% V = V_opt';
c = size(trainLabel,2);
B2 = ones(numTrain, bit2);
B2(randn(numTrain, bit2) < 0) = -1;
B2(B2 > 0) = 1;
V1 = randn(numTrain, bit1);
V1(randn(numTrain, bit1) < 0) = -1;
V1(V1 > 0) = 1;
V2 = randn(numTrain, bit2);
V2(randn(numTrain, bit2) < 0) = -1;
V2(V2 > 0) = 1;
P1 = randn(bit1, bit2);
P2 = randn(bit2, bit1);
G1 = randn(bit1,c);
G2 = randn(bit2,c);
D = NormalizeFea(trainLabel,1);
% figure('Color','w');
% h2 = animatedline;
% h2.Color = 'g';
% h2.LineWidth = 1.3;
% h2.LineStyle = '-.';
% title('mAP');
% h1 = animatedline;
% h1.Color = 'r';
% h1.LineWidth = 1.3;
% h1.LineStyle = '-.';
% title('mAP');
% figure('Color','w');
% h3 = animatedline;
% h3.Color = 'k';
% h3.LineWidth = 1.3;
% h3.LineStyle = '-.';
% title('loss function');
for epoch = 1:maxIter
   %% for test instance
   %% sample Sc
    Sc1 = randperm(numTrain, sampleColumn1);
    Sc2 = randperm(numTrain, sampleColumn2);
    
    % update V1,V2
    SX2 = trainLabel * trainLabel(Sc2, :)' > 0;
    SX1 = trainLabel * trainLabel(Sc1, :)' > 0; 
    SY2 = trainLabel(Sc2, :) * trainLabel' > 0;
    SY1 = trainLabel(Sc1, :) * trainLabel' > 0; 
    
    V2 = updateColumnV(V2, B2, SX2, Sc2, bit2, lambda, sampleColumn2, P1, B1, eta);
    V1 = updateColumnV(V1, B1, SX1, Sc1, bit1, lambda, sampleColumn1, P2, B2, eta);
%     V2 = sign(B1 * P1);
%     V1 = sign(B2 * P2);
    
    % update B1,B2    
    [B2,loss2] = updateColumnB(B2, V1, V2, SY2, Sc2, bit2, lambda, sampleColumn2, P2, eta,alpha,databaseL,G2);
    [B1,loss1] = updateColumnB(B1, V2, V1, SY1, Sc1, bit1, lambda, sampleColumn1, P1, eta,alpha,databaseL,G1);
%     B2 = sign(( alpha * databaseL * G2' + eta * V1 * P2')/(alpha * G2 * G2' + eta * P2 * P2'));
%     B1 = sign((alpha * databaseL * G1' + eta * V2 * P1')/(alpha * G1 * G1' + eta * P1 * P1'));

    % update P1,P2

    P1 =  (eta * B1' * B1 + gamma * eye(bit1)) \ (eta * B1' * V2);
    P2 =  (eta * B2' * B2 + gamma * eye(bit2)) \ ( eta * B2' * V1);

    % update G1,G2
    G1 = (alpha * B1' * B1 + gamma * eye(bit1)) \ (alpha *B1' * databaseL);
    G2 = (alpha * B2' * B2 + gamma * eye(bit2)) \ (alpha *B2' * databaseL);
    
   %evaluation
%     tBX = compactbit((XTest*W1)*P1 > 0);
%     tBY = compactbit((YTest*W2)*P2 > 0);
%     ByTrain = compactbit(B2 > 0);
%     BxTrain = compactbit(B1 > 0);
%     ImgToTxt = calcMapTopkMapTopkPreTopkRecLabel(testL, databaseL, tBX, ByTrain, topk);
%     TxtToImg = calcMapTopkMapTopkPreTopkRecLabel(testL, databaseL, tBY, BxTrain, topk);
%     addpoints(h1, epoch, ImgToTxt.map);
%     addpoints(h2, epoch, TxtToImg.map);
%     drawnow;   
%     fprintf('...iter:%d,   i2t:%.4f,   t2i:%.4f\n',epoch, ImgToTxt.map, TxtToImg.map)

    %loss function
    norm1 = loss1;
    norm2 = loss2;
    norm3 = eta * (norm(V1 - B2 * P2, 'fro') + norm(V2 - B1 * P1, 'fro'));
    norm4 = alpha * (norm(databaseL - B1 * G1, 'fro') + norm(databaseL - B2 * G2, 'fro'));
    norm5 = gamma * (norm(G1, 'fro') + norm(G2, 'fro') + norm(P1, 'fro') + norm(P2, 'fro'));
    currentF= norm1 +  norm2 + norm3 + norm4 + norm5;
    fprintf('\nobj at iteration %d: %.4f\n reconstruction error1: %.4f,\n reconstruction error2: %.4f,\n reconstruction error3: %.4f,\n reconstruction error4: %.4f,\n econstruction error5: %.4f,\n', epoch, currentF, norm1, norm2, norm3,norm4,norm5);
%     addpoints(h3, epoch, currentF);
%     drawnow;
end
    %hash function
    W1 = (X1' * X1 + 0.01 * eye(d1)) \ (rou * X1' * B1 + bit2 * X1' * D * D' * B2 * P1') / (rou * eye(bit1) + P1 * (B2' * B2) * P1');
    W2 = (X2' * X2 + 0.01 * eye(d2)) \ (rou * X2' * B2 + bit1 * X2' * D * D' * B1 * P2') / (rou * eye(bit2) + P2 * (B1' * B1) * P2');

%     W1 = (X1' * X1 + 0.01 * eye(d1)) \ (X1' * B1);
%     W2 = (X2' * X2 + 0.01 * eye(d2)) \ (X2' * B2);

    tBX = compactbit((XTest*W1)*P1 > 0);
    tBY = compactbit((YTest*W2)*P2 > 0);
    ByTrain = compactbit(B2 > 0);
    BxTrain = compactbit(B1 > 0);
    ImgToTxt = calcMapTopkMapTopkPreTopkRecLabel(testL, databaseL, tBX, ByTrain, topk);
    TxtToImg = calcMapTopkMapTopkPreTopkRecLabel(testL, databaseL, tBY, BxTrain, topk);

end

%V2, B2, SX, Sc, bit2, lambda, sampleColumn, P1, eta
function U = updateColumnV(U, B, S, Sc, bit, lambda, sampleColumn, P,B1, eta)
m = sampleColumn;
n = size(U, 1);
for k = 1: bit
    TX = lambda * U * B(Sc, :)'/ bit;
    AX = 1 ./ (1 + exp(-TX));
    Bjk = B(Sc, k)';
    p1 = lambda * ((S - AX) .* repmat(Bjk, n, 1)) * ones(m, 1) / bit;
    p2 = (m * lambda^2 + 8 *bit^2 * eta)* U(:, k) / (4 * bit^2);
    temp = U - B1 * P;
    p3 = 2 * eta * temp(:,k);
    p = p1 + p2 - p3 ;
    U_opt = ones(n, 1); 
    U_opt(p < 0) = -1;
    U(:, k) = U_opt;
end
end

%B2 ,V2, SY, Sc, bit2, lambda, sampleColumn, P2, B2, et
function [B,loss] = updateColumnB(B,U_ano, U, S, Sc, bit, lambda, sampleColumn, P,eta,alpha,L,G)
m = sampleColumn;
n = size(U, 1);
for k = 1: bit
    TX = lambda * U(Sc,:) * B' / bit;
    AX = 1 ./ (1 + exp(-TX));
    Ujk = U(Sc, k)';
    temp1 = U_ano * P';
    temp2 = B * P * P';
    temp3 = L * G' - B * G * G';
    p1 = lambda * ((S' - AX') .* repmat(Ujk, n, 1)) * ones(m, 1) / bit;
    p2 = (m * lambda^2 + 8 *bit^2*eta+8 *bit^2*alpha)* B(:, k) / (4 * bit^2);
    p3 = -2*eta*( temp1(:,k)- temp2(:,k)) -2* alpha*temp3(:,k);
    p = p1 + p2 - p3;
    B_opt = ones(n, 1);
    B_opt(p < 0) = -1;
    B(:, k) = B_opt;
end
    theta = lambda * U(Sc, :) * B' / bit;
    l = log(1 + exp(theta)) - S .* theta;
    loss = sum(sum(l));
end


